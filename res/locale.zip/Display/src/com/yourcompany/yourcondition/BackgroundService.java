package com.yourcompany.yourcondition;

import java.lang.reflect.Method;

import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.IBinder;
import android.os.PowerManager;
import android.util.Log;

/**
 * {@code Service} for monitoring the {@code REGISTERED_RECEIVER_ONLY} {@code Intent}s {@link Intent#ACTION_SCREEN_ON} and
 * {@link Intent#ACTION_SCREEN_OFF}.
 */
public final class BackgroundService extends Service
{

	/**
	 * REPRESENTATION INVARIANTS:
	 * <ol>
	 * <li>The {@link #REQUEST_REQUERY} {@code Intent} should not be modified after its static initialization completes</li>
	 * <li>{@link #isRunning} returns true only while the service is running</li>
	 * <li>{@link #mReceiver} is registered only while the service is running</li>
	 * <li>{@link #displayState} must be one of: -1 for unknown, 0 for off, or 1 for on</li>
	 * </ol>
	 */

	/**
	 * {@code Intent} to ask <i>Locale</i> to re-query our conditions. Cached here so that we only have to create this object
	 * once.
	 */
	private static final Intent REQUEST_REQUERY = new Intent(com.twofortyfouram.Intent.ACTION_REQUEST_QUERY);

	static
	{
		/*
		 * The Activity name must be present as an extra in this Intent, so that Locale will know who needs updating. This intent
		 * will be ignored unless the extra is present.
		 */
		REQUEST_REQUERY.putExtra(com.twofortyfouram.Intent.EXTRA_ACTIVITY, EditActivity.class.getName());
	}

	/**
	 * Indicates whether the {@code Service} is running or not. Since a {@code Service} is a singleton object by definition in
	 * Android, we can make this a static global.
	 */
	private static boolean isRunning = false;

	/**
	 * Global state indicating whether the display is on or off.
	 * <p>
	 * One of:
	 * <ol>
	 * <li>-1 for unknown</li>
	 * <li>0 for off</li>
	 * <li>1 for on</li>
	 * </ol>
	 * Because there is no sticky {@code Intent} or any other way read the display's state, the state is unknown until the display
	 * is turned on or off at least once while we are watching.
	 */
	private static int displayState = -1;

	/**
	 * A {@code BroadcastReceiver} to monitor {@link Intent#ACTION_SCREEN_ON} and {@link Intent#ACTION_SCREEN_OFF}.
	 */
	private BroadcastReceiver mReceiver;

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void onCreate()
	{
		super.onCreate();

		/*
		 * Listen continuously for screen Intents. Note that this receiver will also receive a sticky broadcast.
		 */
		mReceiver = new BroadcastReceiver()
		{

			@SuppressWarnings("synthetic-access")
			@Override
			public void onReceive(final Context context, final Intent intent)
			{
				final String action = intent.getAction();

				Log.v("DisplayCondition", String.format("Received Intent action %s", action)); //$NON-NLS-1$ //$NON-NLS-2$

				if (Intent.ACTION_SCREEN_ON.equals(action))
					displayState = 1;
				else if (Intent.ACTION_SCREEN_OFF.equals(action))
					displayState = 0;

				/*
				 * Ask Locale to re-query our condition instances. Note: this plug-in does not keep track of what types of
				 * conditions have been set up. While executing this code, we have no idea whether there are even any Display
				 * conditions within Locale, or whether those conditions are checking for screen on/screen off. This is an
				 * intentional design decision to eliminate all sorts of complex synchronization problems.
				 */
				sendBroadcast(REQUEST_REQUERY);
			}
		};

		/*
		 * This a RECEIVER_REGISTERED_ONLY Intent
		 */
		final IntentFilter filter = new IntentFilter(Intent.ACTION_SCREEN_OFF);
		filter.addAction(Intent.ACTION_SCREEN_ON);
		registerReceiver(mReceiver, filter);

		isRunning = true;
	}

	/**
	 * Determines whether the service is actually running or not.
	 *
	 * @return true if the service is running. False if it is not.
	 */
	public static boolean isRunning()
	{
		return isRunning;
	}

	/**
	 * Gets the current screen state
	 *
	 * @param c {@code Context}
	 * @return 0 for off, 1 for on, -1 for unknown
	 */
	public static int getScreenState(final Context c)
	{
		if (displayState == -1)
		{
			/*
			 * Try using a private API to provide an immediate result. (Otherwise we're stuck with returning -1 for unknown until
			 * the screen state changes). This private API only exists in Android 2.0 or later.
			 */
			try
			{
				final Method screenState = PowerManager.class.getMethod("isScreenOn"); //$NON-NLS-1$

				final PowerManager pm = (PowerManager) c.getSystemService(Context.POWER_SERVICE);
				final Boolean result = (Boolean) screenState.invoke(pm);

				Log.d("DisplayCondition", "State is " + result.toString()); //$NON-NLS-1$ //$NON-NLS-2$

				displayState = result ? 1 : 0;

				return displayState;
			}
			catch (final Exception e)
			{
				Log.e("DisplayCondition", "Error", e); //$NON-NLS-1$ //$NON-NLS-2$
			}
		}

		return displayState;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public IBinder onBind(final Intent arg0)
	{
		return null;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void onDestroy()
	{
		super.onDestroy();

		unregisterReceiver(mReceiver);
		isRunning = false;
	}

}