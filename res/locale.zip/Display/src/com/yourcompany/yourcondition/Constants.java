package com.yourcompany.yourcondition;

/**
 * Class of {@code Intent} constants used by this <i>Locale</i> plug-in.
 */
final class Constants
{
	/**
	 * Private constructor prevents instantiation
	 *
	 * @throws UnsupportedOperationException because this class cannot be instantiated.
	 */
	private Constants()
	{
		throw new UnsupportedOperationException(String.format("%s(): This class is non-instantiable", this.getClass().getSimpleName())); //$NON-NLS-1$
	}

	/**
	 * TYPE: {@code boolean}
	 * <p>
	 * True means display is on. False means off.
	 */
	protected static final String BUNDLE_EXTRA_BOOLEAN_STATE = "com.yourcompany.yourcondition.extra.STATE"; //$NON-NLS-1$
}